<?php
$conexion = mysqli_connect("localhost", "root","","login");
mysqli_set_charset($conexion,"utf8");
if (!$conexion) {
	echo "Error al conectar";
}
else{
echo "";

}

?>
<?php
	$database="login";
	$user='root';
	$password='';


try {
	
	$con=new PDO('mysql:host=localhost;dbname='.$database,$user,$password);

} catch (PDOException $e) {
	echo "Error".$e->getMessage();
}
