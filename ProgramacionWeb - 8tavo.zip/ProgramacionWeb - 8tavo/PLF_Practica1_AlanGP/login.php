<?php 
include "conexion.php";
?>
<?php 
if ($_POST) {
  session_start();
         include("logincodigo.php");      
}
?>
 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="UTF-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1.0">
 	<link rel="stylesheet" href="diseño.css">
 	<title>Login</title>
 </head>
 <body class="bod">
 	<div class="login-wrap">
 	<div class="container">
 		<h2 >LOGIN</h2>
 		<br>
 		<form action="login.php" method="post">
 			<input class="caja" type="text" name="Nombre" placeholder="   Usuario"value="" autocomplete="off">
 			<input class="caja" type="Password" name="Contrasena" placeholder="   Contraseña" value="" autocomplete="off">
 			<input type="submit" class="boton" name = "submit"value="INICIAR SESIÓN">
 		</form>
 	</div>	
 	</div>
 	
 	
 </body>
 </html>