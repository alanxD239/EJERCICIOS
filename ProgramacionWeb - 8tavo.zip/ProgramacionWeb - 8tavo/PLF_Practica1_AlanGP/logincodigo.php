<?php 
error_reporting(0);
include "conexion.php";
$user=$_POST['Nombre'];
$pass=$_POST['Contrasena'];
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.css"/>
   <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/6.11.0/sweetalert2.js"></script>
</head>
<body class="bod">
  
</body>
</html>
<?php 
$consulta=$conexion->query("SELECT * FROM usuarios WHERE  Nombre='$user' &&  Contrasena='$pass'");
$_SESSION=mysqli_fetch_array($consulta);

if($_SESSION['Nombre']==true){
    header("location:Inicio.php");
    
}if($_SESSION['Nombre']!=$user || $_SESSION['Contrasena']!=$pass){
	echo "<script> swal({
                title: '¡Error!',
                text: 'Matricula o Contraseña Incorrecta',
                type: 'error',
                });</script>";
}else if($_SESSION['Nombre']==""  || $_SESSION['Contrasena'] ==""){
	echo "<script> swal({
                title: '¡Error!',
                text: 'Es necesario llenar todos los campos',
                type: 'error',
                });</script>";

}
mysqli_close($conexion);
?>

