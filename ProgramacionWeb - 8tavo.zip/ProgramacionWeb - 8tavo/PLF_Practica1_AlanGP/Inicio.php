<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>INICIO</title>
</head>
<body>
	<table class="head" border="1" align="center">
		<tr>
			<td><FONT SIZE=2 COLOR="#fff" face="Arial">USUARIO</FONT></td>
			
			<td><FONT SIZE=2 COLOR="#fff" face="Arial">CONTRASEÑA</FONT></td>
		</tr>
		<tr>
			<?php 
			include "conexion.php";
			error_reporting(0);

		$sentencia_select=$con->prepare("SELECT *FROM usuarios");
		$sentencia_select->execute();
		$resultado1=$sentencia_select->fetchAll();
 ?>
			<?php foreach($resultado1 as $fila):?>
				<tr >
					
					<td><?php echo $fila['Nombre']; ?></td>
					<td><?php echo $fila['Contrasena']; ?></td>
					
					
			<?php endforeach ?>
			
		</tr>
	</table>
	<style type="text/css">
		table {
    width: 19%;
    border-collapse: collapse;
    background: #C0C0C0;
    align-items: center;

}



table .head{
    background: rgb(128, 128, 128);
    margin-top: 100px;
}
table .head td{
    color: #fff;
    align-items: center;
    font-family: 'Arial',sans-serif;
    font-size: 15px;
    text-align: center;
    margin-top: 100px;
}

table tr td{
    border:4px solid #ccc;
    padding: 8px;
    font-size: 14px;
    color: #555;
    align-items: center;
    margin-top: 100px;
    
}
	
</body>
</html>