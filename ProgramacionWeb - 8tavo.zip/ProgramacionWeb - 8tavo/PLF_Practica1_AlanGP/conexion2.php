<?php 
    $host="host=localhost";
    $port="port=5432";
    $dbname="dbname=Pedidos_3852";
    $user="user=postgres";
    $password="password=12345";

    $bd = pg_connect("$host $port $dbname $user $password");
    if(!'$bd'){
    	echo "Error";

    }else{
    	echo "Fue exitoso";
    }return $bd;
 ?>
